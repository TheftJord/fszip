/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   fszip.h
 * Author: student
 *
 * Created on March 3, 2024, 5:39 PM
 */

#ifndef FSZIP_H
#define FSZIP_H

#ifdef __cplusplus
extern "C" {
#endif

    void fszip(const char* input);


#ifdef __cplusplus
}
#endif

#endif /* FSZIP_H */

