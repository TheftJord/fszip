/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   fsunzip.h
 * Author: student
 *
 * Created on March 3, 2024, 6:52 PM
 */

#ifndef FSUNZIP_H
#define FSUNZIP_H

#ifdef __cplusplus
extern "C" {
#endif

    void fsunzip(const char* inputFile);


#ifdef __cplusplus
}
#endif

#endif /* FSUNZIP_H */

